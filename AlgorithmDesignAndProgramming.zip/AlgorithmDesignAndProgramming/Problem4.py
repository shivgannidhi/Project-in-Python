#Problem 4: My Phone Book System

#Defining a function to Display phone book menu 
#Add,delete,update and find the phone number in the system

def phonebook():
    print('####################################################')
    print('MYPY PHONE BOOK')
    print('#####################################################')
    print('1. Add New Entry')
    print('2. Delete Entry')
    print('3. Update Entry')
    print('4. Lookup Entry')
    print('5. Quit')

num = {}  #Empty dictionary to store the user's name and phone number
choice = 0
phonebook()
while choice != 5:
    try:
        choice = int(input("Enter your choice: "))
        if choice == 1:
     #Adding the new phone number to system
            print("Add Name and Number")
            name = input("Name: ")
            phone = input("Number: ")
            temp=num.get(name)   #temporary to store the phone number
            if temp==phone:   #Checking if the phone number already exist in the system
                print("Number Already exist")
            else:
                num[name] = phone
                print("Number Added successfully")
     #Deleting the phone number to system
        elif choice == 2:
            print("Remove Name and Number")
            name = input("Name: ")
            if name in num: #Check if the name which user wants to delete from the system exist or not
                del num[name]
                print("Number deleted successfully")
            else:
                print(name, " was not found")
     #Updating the phone number:
        elif choice == 3:
            print("Update Entry")
            name = input("Name: ")
            if name in num:     #Check if the name which user wants to update exist or not
                new_number = input('Please enter the updated number: ')
                num[name] = new_number
            else:
                print(name, "was not found")
     #Find the phone number:
        elif choice == 4:
            print("Lookup Number")
            name = input("Name: ")
            if name in num:
                print("The phone number is", num[name])
            else:
                print(name, "was not found")
                choice=input("Do you wish to save it? (Y/N)") 
                if(choice.upper()=="Y"):
                    phone = input("Number: ")
                    num[name] = phone

        elif choice != 5:
            phonebook()
    except Exception as e:
        print("Error Message:",e)
        continue
