#Problem 3: Element Occurence

#Display
print("##############################\nWELCOME TO DBS CONSOLE\n##############################")
import collections #Collections are used to store data

def ElementOccurence():
    try:
        list = []  # Define empty list
        myInput= int(input("Input the number of elements to be stored in the list: ")) #Taking input from user
        print("Input ",myInput," elements in the list : ")  
    
        for i in range(myInput):
            Elements = int(input("Element - "+ str(i) +" : " ))
            list.append(Elements) #Appending Values to the list
    
        a = list 
        #Assigning the occurence of elements to variable a
        counter = collections.Counter(a)
        print("\nThe frequency of all elements of the list:")
        #Iterates dictionary objects to get keys and values differently
        for key, value in counter.items():
            print(str(key) + ' occurs', '->', str(value)+ " times" )
    except ValueError as e:
          print("Invalid Input Entered\nError Message: ",e)

ElementOccurence()