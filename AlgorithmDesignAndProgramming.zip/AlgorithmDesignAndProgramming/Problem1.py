#Problem 1: PAYSLIP

#Display: Take input from user
try:    
    Employee_Name=input("\n Employee Name: \t\t")
    Employee_Number=input("\n Employee Number: \t\t")
    Week_Ending=input("\n Week ending: \t\t\t")
    Hours_Worked=float(input("\n Number of hours worked: \t"))
    Standard_Rate=float(input("\n Hourly Rate: \t\t\t"))
    Overtime_Rate=float(input("\n Overtime Rate: \t\t"))
    Standard_TaxRate=float(input("\n Standard Tax Rate: \t\t"))
    Overtime_TaxRate=float(input("\n Overtime Tax Rate: \t\t"))
    

except ValueError as a: # If the entered details is wrong the error will be shown
    print("Error: Details entered are wrong ",a) 
            

#Calculating overtime work
if(Hours_Worked>37.5): 
    Standard_Hours = 37.5
    Overtime_Hours = Hours_Worked-37.5
else:
    Standard_Hours=Hours_Worked
    Overtime_Hours=0

#Calculating Overtime Rate
Overtime_Rate*=Standard_Rate 

#Calculating total pay
Standard_Pay = Standard_Hours * Standard_Rate
Overtime_Pay = Overtime_Hours * Overtime_Rate
Gross_Pay = Standard_Pay+Overtime_Pay


#Calculating Tax
Standard_Tax= (Standard_TaxRate/100) * Standard_Pay
Overtime_Tax= (Overtime_TaxRate/100) * Overtime_Pay
Deductions = Standard_Tax + Overtime_Tax

#Calculating Net Pay
Net_Pay=Gross_Pay-Deductions

#Displaying Output Screen
print("\n\n\t\t\t P A Y S L I P")
print("WEEK ENDING ",Week_Ending)
print("Employee: ",Employee_Name)
print("Employee Number: ",Employee_Number)
print("\t\t\t  Earnings\t\t  Deductions\n\t\t\t Hours   Rate   Total")
#Normal 
print("Hours (normal) \t\t",round(Standard_Hours,2),"\t", round(Standard_Rate,2),"\t",round(Standard_Pay,2),"","Tax @",str(round(Standard_TaxRate,2))+"%",round(Standard_Tax,2))
#Overtime
print("Hours (overtime)\t",round(Overtime_Hours,2),"\t", round(Overtime_Rate,2),"\t",round(Overtime_Pay,2),"\t","Tax @",str(round(Overtime_TaxRate,2))+"%",round(Overtime_Tax,2))
#Final
print("\n\t\t\t Total pay:\t\t\t ",round(Gross_Pay,2))
print("\t\t\t Total deductions:\t\t ",round(Deductions,2))
print("\t\t\t Net pay:\t\t\t ",round(Net_Pay,2))


