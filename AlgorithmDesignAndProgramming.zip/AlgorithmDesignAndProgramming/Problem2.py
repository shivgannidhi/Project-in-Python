#Problem2: Domain\Username
#Display 
print("##################################\nWELCOME TO DBS CONSOLE\n##################################")
#User will enter the input as Domain\Username
string=input("Enter your username:\n")
try:
    #Find the occurence of "\"
    i=string.index("\\")
    length=len(string)
    Domain=string[0:i]
    User_Name=string[i+1:length]

    #Display Output
    print("Domain : ",Domain)
    print("Username: ",User_Name)
except ValueError as a:    #Display the error message
    print("Enter Valid Username\nError Message:",a)






