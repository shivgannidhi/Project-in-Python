def remove_duplicates(listofElements):
    uniqueList=[]
    for num in listofElements:
        if num not in uniqueList:
            uniqueList.append(num)
    return uniqueList

listofNum = [10,5,2,45,6,5,2,10,11]
print("Original list:", listofNum)
listofNum = remove_duplicates(listofNum)
print("List with unique number:", listofNum )

