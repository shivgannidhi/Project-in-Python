def Factorial():
    x=int(input("Enter the number: "))
    Fact=1
    while (x!=0):
        Fact=Fact*x
        x-=1
    print(Fact)
Factorial()



