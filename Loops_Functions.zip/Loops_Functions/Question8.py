def Count(sequence,item):
    counter=0
    for element in sequence:
        if (element==item):
            counter=counter+1
    return counter

sequence=[3,5,6,8,3,6,3,6,7]
item=6
total=Count(sequence,item)
print("The number 6 appeared",total , "times")

