hobbies=[]


for i in range(0,3):
    hobby=input("Please enter your three hobbies: ")
    hobbies.append(hobby)

print(hobbies)