def is_even():
    x=int(input("Check if the entered number is even: "))
    if x%2==0:
       return True
    else:
        return False


print(is_even())