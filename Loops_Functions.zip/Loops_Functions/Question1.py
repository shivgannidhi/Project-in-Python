import random
random_number=random.randint(0,10)


guesses_left=3
while guesses_left>0:
    guess=float(input("Guess the number: "))

    if guess==random_number:
        print("You Win!")
        break
        guesses_left-=1
    else:
        print("You lose")
        break
